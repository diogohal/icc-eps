# EP-02

Este trabalho tem como objetivo analisar métodos de resolução de sistemas lineares por meio de três distintas eliminações gaussianas: clássica com pivoteamento parcial, sem multiplicador e com pivoteamento parcial, sem pivoteamento parcial.
Diogo Henrique de Almeida    GRR20210577
Pedro Willian Aguiar         GRR20211766

## Modo de execução
Para executar, digite source ./script.sh arquivo, sendo o arquivo o nome de um arquivo que contem uma matriz teste OU um diretório com vários arquivos que contem uma matriz teste.

## Limitações
Para a matriz de tamanho 17 no arquivo sistemas.dat, o programa retorna vários nan como resposta dos dois últimos métodos de eliminação de gauss. Os testes foram realizados nos computadores do DINF, portanto em outras máquinas podem haver resultados distintos.


